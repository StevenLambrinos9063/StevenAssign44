Steven Lambrinos N01429063 RNA

#Assignment 4
This application uses navigation drawer as it's interface.

The app has 5 different pages and a top bar menu with three different icons.
The top bar menu has a selection: help, settings, and home.
Help opens a website, settings opens the settings app on the phone, home send the user to the home page of the app.

The app has 5 pages: Home, Download, Weather, File Content, and Setting

The home page has the current date and time that is continuously updating, When app resumes it stores "Steven Lambrinos" into Persistent file.
It also has a editText field which allows the user for input, the input then gets stored into a file on button click.

The download page has a list view with 3 options: Cats, Cars, Pizza.
When a item is clicked, the app downloads a image and displays it, this page also displays a textView that shows the contents of the persistent file from the first page.

The weather page displays a list of four Cities, when a city is selected it will display the key information.

The file content page has 2 button, one of them shows the content of the file that was saved with the users input.
The second button deletes the file.

The settings page is under construction.
